<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>Ŀ¼����</title>
<style type="text/css">
a:link {
	font-size: 14px;
	line-height: normal;
	color: #03F;
	text-decoration: none;
}
a:visited {
	font-size: 14px;
	color: #03F;
	text-decoration: none;
}
a:hover {
	font-size: 14px;
	color: #093;
	text-decoration: none;
}
</style>
</head>
<body>
<?php
	if(!empty($_GET['c_f']))
		{$c_dir=$_GET['c_f'];}//��ȡ��ǰĿ¼����
	else
		{$c_dir=getcwd();}
	chdir($c_dir);//�ı䵱ǰ����Ŀ¼
?>
<pre>
��ǰĿ¼��</pre>
<pre>
<?php
	echo "<img src='folder_c.png' width='16' height='16'>";
	echo "<a href='dir_tree.php?c_f=".dirname($c_dir)."'>".dirname($c_dir)."</a>";
	echo "\\".basename($c_dir)."<br>";
	$list=scandir($c_dir);	//ɨ�赱ǰĿǰ�е���Ŀ
	foreach($list as $k)
		{	if($k!="."&&$k!="..")
			{if(is_dir(realpath($k)))	//�ļ������ļ�������ʾ
				{	echo "   |-<img src='folder.png' width='12' height='14'>";
					echo "<a href='dir_tree.php?c_f=".realpath($k)."'>";
					printf("%'--20s",$k);
					echo "</a>";
					echo " <a href='dir_rename.php?c_f=".$c_dir."&c_dirname=".$k."'>[������]</a> ";
					echo "<a href='dir_delete.php?c_f=".$c_dir."&c_dirname=".$k."'>[ɾ��]</a>";
					echo "<br>";}
			else
				{echo "   |-<img src='file.png' width='12' height='14'>".$k."<br>";}}
		}
?>
</pre>
</body>
</html>