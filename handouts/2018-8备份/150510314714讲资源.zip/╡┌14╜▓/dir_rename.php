<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�ޱ����ĵ�</title>
</head>

<body>
<?Php
	if(!empty($_POST['new_dirname']))
		{$c_f=$_GET['c_f'];	//��ǰĿ¼·��
		 $c_dirname=$_GET['c_dirname'];//������ļ�������
		 $old_name=$c_f."\\".$c_dirname;
		 $new_name=$c_f."\\".$_POST['new_dirname'];
		 rename($old_name,$new_name);
		 header("location:dir_tree.php?c_f=$c_f");
		}
	else
		{$c_f=$_GET['c_f'];	//��ǰĿ¼·��
		 $c_dirname=$_GET['c_dirname'];//������ļ�������
		}
?>
<form id="form1" name="form1" method="post" action="dir_rename.php?c_f=<?php echo $c_f;?>&c_dirname=<?php echo $c_dirname;?>">
������<?php echo $c_dirname;?>��������:<br>
  <table width="300" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td bgcolor="#F0F0F0"><label for="new_dirname"></label>
      <input type="text" name="new_dirname" id="new_dirname" />
      <input type="submit" name="button" id="button" value="ȷ��" /></td>
    </tr>
  </table>
</form>
</body>
</html>