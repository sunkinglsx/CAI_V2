<style type="text/css">
#dia {
	position: absolute;
	width: 314px;
	height: 83px;
	z-index: 1;
	left: 459px;
	top: 194px;
	visibility: hidden;
	padding: 15px;
}
#dia {
	background-color: #E8E8E8;
	border: 1px solid #CCC;
}
</style>
<div id="dia">
  <p>��������Ŀ¼���ƣ�</p>
  <form id="form2" name="form2" method="post" action="">
    <label for="newdir"></label>
    <input type="text" name="newdir" id="newdir" />
    <input type="submit" name="button2" id="button2" value="������" />
  </form>
</div>
<script language="javascript">
	function show_dia()
	{
		document.getElementById("dia").style.visibility="visible";
	}
		function hide_dia()
	{
		document.getElementById("dia").style.visibility="hidden";
	}

</script>
<form id="form1" name="form1" method="post" action="">
  <label for="dirname"></label>
  <input type="text" name="dirname" id="dirname" />
  <input type="submit" name="button" id="button" value="�½�Ŀ¼" />
</form>
<?php
	$path='dir1';
	$i=is_dir($path);
	//�½�Ŀ¼
	if(isset($_POST['button']))
	{
		$newdir=$_POST['dirname'];
		$newpath=$path."\\".$newdir;
		mkdir($newpath);
	}
	//������
	if(isset($_GET['d']))
	{
		$old_dir=$_GET['d'];
		echo "<script language='javascript'>show_dia();</script>";
	}
	if(isset($_POST['button2']))
	{
		$new_name=$_POST['newdir'];	//���ļ�������
		$new_dir=dirname($old_dir)."\\".$new_name;	//���ļ���·��
		rename($old_dir,$new_dir);	//������
		header("location:dir.php");	//��ת��Ŀ¼�б�ҳ��
	}
	//ɾ��Ŀ¼
	if(isset($_GET['r']))
	{
		$d=$_GET['r'];
		if(is_dir($d))
		{
			rmdir($d);
		}
	}
	//���Ŀ¼	
	if($i)
	{
		$dir_id=opendir($path);
		if($dir_id)
			echo "��Ŀ¼�ɹ����������£�<br>";
			while($list=readdir($dir_id))
			{
				if($list!="."&&$list!="..")
				{
					if(is_dir($path."\\". $list))
						echo "<img src='folder.png'>";
					else
						echo "<img src='file.png'>";
					$del_dir=$path."\\".$list;
					echo $list."<a href='dir.php?r=".$del_dir."'>[ ɾ�� ]</a> 
					&nbsp;&nbsp;&nbsp;<a href='dir.php?d=".$del_dir."'>[������]</a><br>";
				}
			}
	}
	else
		echo "·���Ƿ�";
?>
