<?php 
	$newdir='dir2\913';
	if(!is_dir($newdir))
		mkdir($newdir,0777,true);
	else
		echo "文件夹已存在";
?>