<style type="text/css">
body {
	line-height: 23px;
}
a:link {
	text-decoration: none;
	color: #000;
}
a:visited {
	text-decoration: none;
	color: #000;
}
a:hover {
	text-decoration: none;
	color: #000;
}
#dialog {
	position: absolute;
	width: 275px;
	height: 102px;
	z-index: 1;
	left: 439px;
	top: 158px;
	color: #666;
}
#dialog {
	color: #000000;
	border: 1px solid #666;
	background-color: #CCC;
	padding-left: 10px;
	padding-top: 10px;
	visibility: hidden;
}
#trees {
	position: absolute;
	width: 492px;
	height: 416px;
	z-index: 2;
	left: 433px;
	top: 101px;
}
#trees {
	text-decoration: none;
	padding: 10px;
	border: 1px solid #669;
	height: auto;
	visibility: hidden;
}
</style>
<script type="text/javascript">
	function show_dialog()
	{
		document.getElementById("dialog").style.visibility="visible";
	}
	function hide_dialog()
	{
		document.getElementById("dialog").style.visibility="hidden";
	}
	function show_trees()
	{
		document.getElementById("trees").style.visibility="visible";
	}
	function hide_trees()
	{
		document.getElementById("trees").style.visibility="hidden";
	}
</script>
<div id="dialog">
  <form name="form1" method="post" action="">
    <p>��������Ŀ¼���ƣ�
</p>
    <p>
      <label for="newdir"></label>
      <input type="text" name="newdir" id="newdir">
      <input type="submit" name="button" id="button" value="ȷ��">
      <input name="cancel" type="button" value="ȡ��"  onclick="hide_dialog()"/>
    </p>
  </form>
</div>
<?php
	if(isset($_GET['m']))	
	{
		$source_dir=$_GET['s_dir'];	//ԴĿ¼
		$root=dirname($_GET['s_dir']);
		$father_path=dirname($root);	//��Ŀ¼��·��
	}
?>
<div id="trees">
��ѡ��Ҫճ����λ�ã�<br>
<iframe id="tree" name="tree" width="400" height="300" src="todir.php?s_dir=<?php echo $source_dir;?>" frameborder="0"></iframe>
</div>
<pre>
<?php
	$root=dirname(getcwd());	//��Ŀ¼
	if(isset($_GET['d']))
	{
		$root=$_GET['d'];//��ȡ���¹���·��
	}
	$father_path=dirname($root);	//��Ŀ¼��·��
	//����������
	if(isset($_GET['r']))
	{
		echo "<script language='javascript'>show_dialog();</script>>";
		$old_dir=$_GET['f'];
		$root=dirname($_GET['f']);
		$father_path=dirname($root);	//��Ŀ¼��·��
	}
	if(isset($_POST['button']))
	{
		$new_dir_name=$_POST['newdir'];
		$new_path=dirname($old_dir)."\\".$new_dir_name;
		rename($old_dir,$new_path);//������
		echo "<script language='javascript'>hide_dialog();</script>>";
	}
	//�ƶ�Ŀ¼
	if(isset($_GET['m']))	
	{
		$source_dir=$_GET['s_dir'];	//ԴĿ¼
		$root=dirname($_GET['s_dir']);
		$father_path=dirname($root);	//��Ŀ¼��·��
		echo "<script language='javascript'>show_trees();</script>>";
	}
	//��ʾ�ļ���
	echo "<a href='index.php?d=".$father_path."'>".$father_path."</a>\\".basename($root)."<br>";
	$tree=scandir($root);//ɨ���Ŀ¼�����е��ļ���Ŀ¼
	foreach($tree as $t)
		{
			if($t!="."&&$t!="..")
			{
				$path=$root."\\".$t;
				if(is_dir($path))
				{
					echo "<img src='folder.png'>";	//Ŀ¼ͼ��
					echo "<a href='index.php?d=".$path."'> --".$t."</a>";	//�ļ���Ŀ¼����
					echo "............��ɾ����";
					echo "   <a href='index.php?r=1&f=".$path."'>����������</a>";
					echo "   <a href='index.php?m=1&s_dir=".$path."'>�����С�</a>";
					echo "<br>";
				}
				else
				{
					echo "<img src='file.png'>";	//�ļ�ͼ��
					echo " --".$t."<br>";	//�ļ���Ŀ¼����
				}
			}
		}
?>
</pre>
