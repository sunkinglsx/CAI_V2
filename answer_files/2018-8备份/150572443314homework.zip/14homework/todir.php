<style type="text/css">
body {
	line-height: 23px;
}
a:link {
	text-decoration: none;
	color: #000;
}
a:visited {
	text-decoration: none;
	color: #000;
}
a:hover {
	text-decoration: none;
	color: #000;
}
#dialog {
	position: absolute;
	width: 275px;
	height: 102px;
	z-index: 1;
	left: 439px;
	top: 158px;
	color: #666;
}
#dialog {
	color: #000000;
	border: 1px solid #666;
	background-color: #CCC;
	padding-left: 10px;
	padding-top: 10px;
	visibility: hidden;
}
#trees {
	position: absolute;
	width: 492px;
	height: 416px;
	z-index: 2;
	left: 433px;
	top: 101px;
}
#trees {
	text-decoration: none;
	padding: 10px;
	border: 1px solid #669;
	height: auto;
	visibility: hidden;
}
</style>
<script type="text/javascript">
	function hide_trees()
	{
		window.parent.document.getElementById("trees").style.visibility="hidden";
	}
	function win_refresh()
	{
		window.parent.location.href="index.php";
	}
</script>
<form name="form1" method="post" action="">
��ѡ��
<?php
	session_start();
	if(isset($_GET['s_dir']))
		$_SESSION['s_dir']=$_GET['s_dir'];
	$root=dirname(getcwd());	//��ǰĿ¼
	if(isset($_GET['d']))
	{
		$root=$_GET['d'];//��ȡ���¹���·��
	}
	echo $root;
?>
  <input type="submit" name="button" id="button" value="ճ��">
  <input type="button" name="cancel" id="cancel" value="ȡ��" onClick="hide_trees()">
</form>
<?php
	//ճ������
	if(isset($_POST['button']))
	{
		$new_dir_name=$root."\\".basename($_SESSION['s_dir']);
		rename($_SESSION['s_dir'],$new_dir_name);
		echo "<script>win_refresh();</script>";
	}
	$father_path=dirname($root);	//��Ŀ¼��·��
	echo "<a href='todir.php?d=".$father_path."'>".$father_path."</a>\\".basename($root)."<br>";
	$tree=scandir($root);//ɨ���Ŀ¼�����е��ļ���Ŀ¼
	foreach($tree as $t)
		{
			if($t!="."&&$t!="..")
			{
				$path=$root."\\".$t;
				if(is_dir($path))
				{
					echo "<img src='folder.png'>";	//Ŀ¼ͼ��
					echo "<a href='todir.php?d=".$path."'> --".$t."</a>";	//�ļ���Ŀ¼����
					echo "<br>";
				}
			}
		}
?>
