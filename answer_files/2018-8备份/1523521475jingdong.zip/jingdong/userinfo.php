<?php
	session_start();
	if(!isset($_SESSION['yhm']))
	{
		header("location:login.php");
		exit;
	}
	
?>
<table width="881" height="32" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="232" align="center" bgcolor="#E3E4E5" ><font color="#CC0000"><?php echo $_SESSION['yhm'];?></font></td>
    <td width="649" height="32" background="images/s-1_02.gif">&nbsp;</td>
  </tr>
</table>
