<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>京东商城</title>
</head>

<body>

<table width="1186" height="239" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="306" rowspan="2"><img src="images/s-1_01.gif" width="306" height="673" usemap="#Map" border="0" /></td>
    <td width="880" height="36"><?php
	include("userinfo.php");
?></td>
  </tr>
  <tr>
    <td><img src="images/s-1_03.gif" width="881" height="640" /></td>
  </tr>
</table>

<map name="Map" id="Map">
  <area shape="rect" coords="12,246,102,267" href="computer.php" />
  <area shape="rect" coords="12,552,136,574" href="book.php" />
</map>
</body>
</html>