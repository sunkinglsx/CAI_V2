<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>用户登陆</title>
</head>

<body>
<?php
	session_start();	//打开服务器会话
	if(isset($_SESSION['yhm'])&&$_SESSION['yhm']!="")
	{
		echo "欢迎您！".$_SESSION['yhm']."回来本系统";
		echo "<a href='booklist.php'>图书音像</a>&nbsp;&nbsp;";
		echo "<a href='elec.php'>家用电器</a>";
		exit;
	}
?>
<form id="form1" name="form1" method="post" action="login_ver.php">
  <table width="492" height="163" border="1" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td colspan="2" align="center" bgcolor="#FFCCCC">用户登陆</td>
    </tr>
    <tr>
      <td width="153" align="center">账号</td>
      <td width="333"><label for="uname"></label>
      <input type="text" name="uname" id="uname" /></td>
    </tr>
    <tr>
      <td align="center">密码</td>
      <td><label for="pw"></label>
      <input type="text" name="pw" id="pw" /></td>
    </tr>
    <tr>
      <td align="center">验证码</td>
      <td><label for="yzm"></label>
      <input type="text" name="yzm" id="yzm" />
      <?php
	  	//验证码(因子）
	  	$str="ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
		$vercode="";
		$c1=$str[rand(0,34)];
		$c2=$str[rand(0,34)];
		$c3=$str[rand(0,34)];
		$c4=$str[rand(0,34)];
		$vercode=$vercode.$c1.$c2.$c3.$c4;
		echo $vercode;
		$_SESSION['yzm']=$vercode;	  
	  ?>
      
      </td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" name="ok" id="ok" value="登陆" /></td>
    </tr>
  </table>
</form>
</body>
</html>