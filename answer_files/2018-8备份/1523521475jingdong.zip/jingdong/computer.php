<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>京东电脑</title>
</head>

<body>
<table width="1214" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="287" height="30" bgcolor="#E3E4E5">&nbsp;</td>
    <td width="927" bgcolor="#E3E4E5"><?php include ("userinfo.php");?></td>
  </tr>
</table>
<table width="1214" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/p-3.jpg" width="1214" height="674" /></td>
  </tr>
</table>
</body>
</html>